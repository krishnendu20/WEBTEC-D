<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
<footer>
    <fieldset>
      <i><center><h1> <b>Restaurant Arrangement Website</b></h1></center></i>
    </fieldset>
</footer>
  </body>
</html>
