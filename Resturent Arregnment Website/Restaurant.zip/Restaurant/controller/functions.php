<?php

$con = mysqli_connect("localhost","root","","restaurant") or die("Connection was not established");


function insertPost(){
	if(isset($_POST['sub'])){
		global $con;
		global $user_id;
	
}
}


?>
