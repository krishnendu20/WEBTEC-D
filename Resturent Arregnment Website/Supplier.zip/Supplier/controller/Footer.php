<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
<footer>
  <form>
    <fieldset>
      <center><p> <b>Copyrights&nbsp&nbsp&copy <?php echo date("Y/m/d") ; ?></b></p></center>
    </fieldset>
  </form>

</footer>
  </body>
</html>
