<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <i><center><h1>Supplier DashBoard</h1></center></i>
     <center>
       <hr><hr>
       <form align="right" name="form1" method="post" action="../view/logout.php">

<input name="submit2" type="submit" id="submit2" value="Logout">
</form>
       <a href="../view/home.php">
        <button>Home</button> </a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href="../view/Delivary.php">
            <button>Product Delivary</button>
          </a>
        &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href="../view/changeprice.php">
           <button>Change Prices</button>
         </a>
       &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href="../view/confirm2.php">
      <button>Delivary Commitments</button>
    </a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href="../view/Profile.php">
        <button>Profile</button>
      </a>
    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href="../view/confirm1.php">
        <button>Save Resources</button>
      </a>
     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href="../view/notification.php">
        <button>Activities</button>
    
          </a>
    </center>
<hr><hr>

  </body>
</html>
