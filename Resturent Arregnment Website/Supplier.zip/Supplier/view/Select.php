<!DOCTYPE html>
<html>
<head>
	<title>Select Role</title>
<meta charset="utf-8">

</head>
  <body>
		<fieldset>
 
  <form  action="./view/Supplier_Login.php">
    <fieldset>
     <center><legend><h3>Supplier Login</h3></legend></center><br><br>
     
    </fieldset><br><hr>
    <center><input type="submit" class="btn btn-info" name="submit" style="width:200px;" value="
Proceed"><center>

</form><br>
<fieldset>
	<center><p> <b>Copyrights&nbsp&nbsp&copy <?php echo date("Y/m/d") ; ?></b></p></center>
</fieldset>
  </body>
</html>
