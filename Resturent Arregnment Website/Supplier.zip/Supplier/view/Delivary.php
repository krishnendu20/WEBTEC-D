<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <?php
      require '../controller/header.php';
    ?>
  <body>
    <br><br><br><hr>
     <i><center><h1>Product Delivary</h1></center></i>
     <hr><br><br>
     <center><i><h3>Delivary List</h3></i></center>
   
      <table border="10" align = "center">
      <thead>
      <tr>
       <th>Product Name</th>
       <th>Product Type</th>
       <th>Delivary Address</th>
       <th>Product Status</th>
       <th>Amount</th>
      </tr>
      </thead>
      <tbody>
        <tr>
       <td>Burger</td>
       <td>Fast Food</td>
       <td>Gulshan</td>
       <td>Active</td>
       <td>300</td>
      </tr>
      <tr>
       <td>Pizza</td>
       <td>Fast Food</td>
       <td>Boshundhora</td>
       <td>Active</td>
       <td>900</td>
      </tr>
      </tbody>

  </body>
</html>
