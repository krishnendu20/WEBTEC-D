
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <?php
      require '../controller/header.php';
    ?>
  <body>
  <br><br><br><hr>
  <i><center><h1>Activities</h1></center></i>
  <hr><br><br>

<br><br>
   <i><h3>Track ...</h3></i>
   <form action="edit_profile.php" method="POST">
    <br>
    <fieldset>
      <br>

      <p>Food Performance : <b>Not Bad</b> &nbsp; </p>

      <p>Food Quality Audits : <b> Varified</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </p>

      <p>Assessment:<b> Done</b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </p>

      <p>Report : The was good enough.<b> Everything is doing good.</b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </p>

      <br>
    </fieldset>

  </form>
  
 </body><br><br>

</html>
